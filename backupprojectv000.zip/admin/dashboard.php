<?php
include '../config.php';
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>dashbord design</title>
    <link rel="stylesheet" href="style.css">
     <link rel="stylesheet" href=" https://cdnjs.cloudflare.com/ajax/libs/akar-icons-fonts/1.1.20/css/akar-icons.css">
    
</head>
<body>
    <div class="sidebar">
        <div class="logo"><h4>ONLINE PASAL</h4></div>
        <ul class="menu">
           <li class="active">
            <a href="dashboard.php">
                <i class="fas fa-tachometer-alt"></i>
                <!-- <i><img src="../img/dashboard.png" class="side-icon"></i> -->
                <span>Dashboard</span>
            </a>
           </li>
           <li>
            <a href="#">
                <i class="fas fa-user"></i>
                <span>Profile</span>
            </a>
           </li>
           <li>
            <a href="productstable.php">
            <i class="fa-solid fa-gift"></i>
                <span>Products</span>
            </a>
           </li>
           <li>
            <a href="userstable.php">
            <i class="fa-solid fa-user-plus"></i>
                <span>Users</span>
            </a>
           </li>
           <li>
            <a href="#">
            <i class="fa-solid fa-truck"></i>
                <span>Orders</span>
            </a>
           </li>
           <li>
            <a href="#">
            <i class="fa-sharp fa-solid fa-cart-plus"></i>
                <span>Category</span>
            </a>
           </li>
           
           <li class="logout">
            <?php
               if(isset($_SESSION['user_type'])){
             echo'<a href="../log_out.php" onclick="return confirm(\'You Are Sure You Want To Logout?\');">
            <i class="fa-solid fa-right-from-bracket"></i>
                <span>Logout</span>
            </a>';
               }
            ?>
           </li>
        </ul>
    </div>
<!-- main body section -->
    <div class="main-content">
        <div class="header-wrapper">
            <div class="header-title">
                <span>Admin</span>
                <h2>Dashboard</h2>
            </div>
            <div class="user-info">
                <a href="profile.php"><img src="./profile/pic1.jpg" alt=""></a>
                <!-- <a href="profile.php"><img src="./profile/blankimage.png" alt=""></a> -->
            <select>
                <option>profile</option>
                <option value="home">home</option>
                <option value="logout">Logout</option>
            </select>
            </div>
        </div>

        <!-- card-container -->
        <div class="card-container">
        <h3 class="main-title">Today data</h3>
        <div class="card-wrapper">
            <div class="payment-card light-red">
                <div class="card-header">
                    <div class="amount">
                        <span class="title">Total Users</span>
                        <span class="amount-value">$500.00</span>
                    </div>
                    <!-- <i class="fa-solid fa-users icon"></i> -->
                    <img src="../img/users.png" class="icon">
                </div>
                <span class="card-detail">****888****</span>
            </div>

            <div class="payment-card light-purple">
                <div class="card-header">
                    <div class="amount">
                        <span class="title">Total Products</span>
                        <span class="amount-value">$500.00</span>
                    </div>
                    <!-- <i class="fa-solid fa-gift icon dark-purple"></i> -->
                    <img src="../img/product.png" class="icon dark-purple">
                </div>
                <span class="card-detail">****888****</span>
            </div>

            <div class="payment-card light-green">
                <div class="card-header">
                    <div class="amount">
                        <span class="title">Total Orders</span>
                        <span class="amount-value">$500.00</span>
                    </div>
                    <!-- <i class="fa-solid fa-truck icon dark-green"></i> -->
                    <img src="../img/order.png" class="icon dark-green">
                </div>
                <span class="card-detail">****888****</span>
            </div>

            <div class="payment-card light-blue">
                <div class="card-header">
                    <div class="amount">
                        <span class="title">Catrgory</span>
                        <span class="amount-value">$500.00</span>
                    </div>
                    <!-- <i class="fa-solid fa-chart-line icon dark-blue"></i> -->
                    <img src="../img/category.png" class="icon dark-blue">
                </div>
                <span class="card-detail">****888****</span>
            </div>
        </div>
    </div>

    <div class="tabular-wrapper">
        <h3 class="main-title">Available User</h3>
        <div class="table-container">

        <?php
          $i = 1;
          $rows = mysqli_query($conn, "SELECT *FROM signup");
          if(mysqli_num_rows($rows)>0){

           echo' <table>
                <thead>
                    <tr>
                        <th>No</th>
                        <th>User Id</th>
                        <th>Full Name</th>
                        <th>Email</th>
                        <th>Phone No</th>
                        <th>Address</th>
                        <th>User Type</th>
                        <th>Date & Time</th>
                    </tr>
                </thead>';
                ?>
                <?php foreach($rows as $row) : ?>
        <tr>
            <td><?php echo $i++; ?></td>
            <td><?php echo $row["id"]; ?></td>
            <td><?php echo $row["fname"]; ?></td>
            <td><?php echo $row["email"]; ?></td>
            <td><?php echo $row["phone"]; ?></td>
            <td><?php echo $row["address"]; ?></td>
            <td><?php echo $row["user_type"]; ?></td>
            <td><?php echo $row["dt"]; ?></td>
        </tr>
          <?php 
          endforeach; 
        }
          else{
            echo"<div class='empty_text'>No User Available</div>";
          }
          ?>
            </table>
        </div>
    </div>
    </div>
</body>
</html>