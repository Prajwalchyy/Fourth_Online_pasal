<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>header page</title>
    <link rel="stylesheet" href="index.css">
</head>
<body>
<div class="headerbox">
     <div class="headernavbar">
         <div class="headerlogo">
            <img src="img/onlinepasallogo.jpeg" width="80px">
         </div>
         <nav>
            <ul>
                <li><a href="">Home</a></li>
                <li><a href="">Products</a></li>
                <li><a href="">About</a></li>
                <li><a href="">Shop</a></li>
                <li><a href=""></a></li>
                <?php
                     if(isset($_SESSION['user_type'])){
                        echo '<li><a href="login.php"><button class="btnlogin">Login</button></a></li>';
                    
                    } else {
                        echo '<li><a href="logout.php" onclick="return confirm(\'You Are Sure You Want To Logout?\');"><button class="btnlogin"><b>Logout</b></button></a></li>';
                            }
                         ?>

            </ul>
         </nav>

     </div>
</div>
    
</body>
</html>