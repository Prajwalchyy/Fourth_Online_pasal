<?php
include 'config.php';

$sql = "SELECT * FROM products";
$all_product = $conn->query($sql);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>products page</title>
    <link rel="stylesheet" href="index.css">
</head>
<body>
<div class="header">
        <?php
          include 'header.php';
        ?>
    </div>
    <h3 class="main-title">All Products</h3>
    <?php
        while($row = mysqli_fetch_assoc($all_product)){
    ?>
    <div class="products-container">
        <!-- <h3 class="main-title">All Products</h3> -->
        <div class="products-wrapper">
            <div class="product-frame">
                <img src="img/productimage/<?php echo $row["image"]; ?>" class="products-img">
                <div class="product-overlay"></div>
                <div class="products-body">
                    <h4 class="products-title"><?php echo $row["productName"]; ?></h4>
                    <p class="products-price">price:<?php echo $row["price"]; ?></p>
                    <button type="submit" class="add-to-cart-btn">Add To Cart</button>
                    <button class="details-btn">Details</button>
                </div>
            </div>
        </div>
    </div>
    <?php
        }
    ?>
</body>
</html>