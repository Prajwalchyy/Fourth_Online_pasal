<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>footer page</title>
    <link rel="stylesheet" href="index.css">
</head>
<body>
    <div class="footerbackground">
      <div class="footercontactus">
          <h1>Contact Us:</h1>
      <a href="https://mail.google.com/mail/u/0/#inbox?compose=CllgCJNsLvWJZnMjHKrlxJhJvfTcGrFQsphlclvTjckRjXLrTxzXMxppXWLShMSvfVdFnzQnCKL">nc72723@gmail.com</a><br>
      <a href="https://mail.google.com/mail/u/0/#inbox?compose=GTvVlcSBpDfsGzrtxlZdkHrWVPwnzCxWdxKbpltTTxlnpSvghJwxlCzzqPFvpXXHXRPWqKVVhmRhR">chaudharynir1999@gmail.com</a><br>
      <a href="https://mail.google.com/mail/u/0/#inbox?compose=GTvVlcSBpDfsGzrtxlZdkHrWVPwnzCxWdxKbpltTTxlnpSvghJwxlCzzqPFvpXXHXRPWqKVVhmRhR">prajwalchaudharyy111@gmail.com</a>

      </div>
      <div class="footercopyright">
           2022 Copyright © Online Pasal.
      </div>
    </div>
    
</body>
</html>