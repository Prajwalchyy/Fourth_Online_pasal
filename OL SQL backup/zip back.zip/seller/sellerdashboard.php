<?php
include '../config.php';
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>dashbord design</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
</head>
<body>
    <div class="sellerdashboard-sidebar">
        <div class="logo"><h4>ONLINE PASAL</h4></div>
        <ul class="sellerdashboard-menu">
           <li class="active">
            <a href="dashboard.php">
                <i class="fas fa-tachometer-alt"></i>
                <span>Dashboard</span>
            </a>
           </li>
           <li>
            <a href="#">
                <i class="fas fa-user"></i>
                <span>Profile</span>
            </a>
           </li>
           <li>
            <a href="producttable.php">
            <i class="fa-solid fa-gift"></i>
                <span>Products</span>
            </a>
           </li>
           <li>
            <a href="#">
            <i class="fa-solid fa-truck"></i>
                <span>Orders</span>
            </a>
           </li>
           
           <li class="logout">
            <?php
               if(isset($_SESSION['user_type'])){
             echo'<a href="../logout.php" onclick="return confirm(\'You Are Sure You Want To Logout?\');">
                <i class="fa-solid fa-right-from-bracket"></i>
                <span>Logout</span>
            </a>';
               }
            ?>
           </li>
        </ul>
    </div>
<!-- main body section -->
    <div class="sellerdashboard-main-content">
        <div class="sellerdashboard-header-wrapper">
            <div class="sellerdashboard-header-title">
                <span>Seller</span>
                <h2>Dashboard</h2>
            </div>
            <div class="user-info">
                <!-- <a href="#"><img src="../admin/profile/pic1.jpg" alt="">Profile</a> -->
                 <a href="profile.php"><img src="../admin/profile/blankimage.png" alt=""></a>
             <select>
                <option>profile</option>
                <option value="home">home</option>
                <option value="logout">Logout</option>
            </select>
            </div>
        </div>

        <!-- secondbox-container -->
        <div class="secondbox-container">
        <div class="secondbox-wrapper">
            <div class="box light-red">
                <div class="box-header">
                    <div class="total-data">
                        <span class="title">Total Users</span>
                        <span class="total-data-value">$500.00</span>
                    </div>
                    <i class="fa-solid fa-users icon"></i>
                </div>
                <span class="box-detail">****888****</span>
            </div>

            <div class="box light-purple">
                <div class="box-header">
                    <div class="total-data">
                        <span class="title">Total Products</span>
                        <span class="total-data-value">$500.00</span>
                    </div>
                    <i class="fa-solid fa-gift icon dark-purple"></i>
                </div>
                <span class="box-detail">****888****</span>
            </div>

            <div class="box light-green">
                <div class="box-header">
                    <div class="total-data">
                        <span class="title">Total Orders</span>
                        <span class="total-data-value">$500.00</span>
                    </div>
                    <i class="fa-solid fa-truck icon dark-green"></i>
                </div>
                <span class="box-detail">****888****</span>
            </div>
        </div>
    </div>

    <div class="tabular-wrapper">
        <h3 class="main-title">Available User</h3>
        <div class="table-container">

        <?php
          $i = 1;
          $rows = mysqli_query($conn, "SELECT *FROM signup");
          if(mysqli_num_rows($rows)>0){

           echo' <table>
                <thead>
                    <tr>
                        <th>No</th>
                        <th>User Id</th>
                        <th>Full Name</th>
                        <th>Email</th>
                        <th>Phone No</th>
                        <th>Address</th>
                        <th>User Type</th>
                        <th>Date & Time</th>
                    </tr>
                </thead>';
                ?>
                <?php foreach($rows as $row) : ?>
        <tr>
            <td><?php echo $i++; ?></td>
            <td><?php echo $row["id"]; ?></td>
            <td><?php echo $row["fname"]; ?></td>
            <td><?php echo $row["email"]; ?></td>
            <td><?php echo $row["phone"]; ?></td>
            <td><?php echo $row["address"]; ?></td>
            <td><?php echo $row["user_type"]; ?></td>
            <td><?php echo $row["dt"]; ?></td>
        </tr>
          <?php 
          endforeach; 
        }
          else{
            echo"<div class='empty_text'>No User Available</div>";
          }
          ?>
            </table>
        </div>
    </div>
    </div>
</body>
</html>