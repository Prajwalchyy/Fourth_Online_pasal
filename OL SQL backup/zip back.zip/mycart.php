<?php
include 'config.php';
include 'header.php';
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>cart</title>
    <link rel="stylesheet" href="index.css">
</head>
<body>
    <div class="cart_container">
        <div class="cart_row">
            <div class="cart_heading">
              <h1>MY CART</h1>
            </div>
        </div>
        <div class="cart_table_container">
            <table class="cart_table">
                <thead>
                    <tr>
                        <th>Serial No.</th>
                        <th>Item Name</th>
                        <th>Item Price</th>
                        <th>Quantity</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $total=0;
                    if(isset($_SESSION['cart']))
                    {
                         foreach($_SESSION['cart'] as $key => $value)
                         {
                            $total=$total+$value['price'];
                             echo"
                               <tr>
                                  <td>1</td>
                                  <td>$value[product_Name]</td>
                                  <td>$value[price]</td>
                                  <td><input class='text-center' type='number'value='$value[quantity]' min='1' max='10'></td>
                                  <form>
                                  <td><button class='remove_btn'>REMOVE</button></td>
                                  </form>
                               </tr>";
                         }
                    }
                    ?>
                </tbody>
            </table>
        </div>
        <div class="cart_total">
            <h3>Total:</h3>
            <h5><?php echo $total ?></h5>
            <br>
            <form>
                <div class="form_cheak">
                    <input type="radio">
                    <label>Cash on delivery</label>
                </div>
                <button class="make_purchase_btn">Make Purchase</button>
            </form>
        </div>
    </div>
    
</body>
</html>