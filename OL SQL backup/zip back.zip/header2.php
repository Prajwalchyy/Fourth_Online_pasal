<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>header2page</title>
    <link rel="stylesheet" href="index.css">
</head>
<body>
<img  class="bg" src="img/onlineshopping.jpg" alt="">
    <div class="header2box">
        .
      <ul class="header2menu">
         <li><a href="#"><b>New</b></a></li>
         <li><a href="#"><b>Old</b></a></li>
         <form method="post">
	            <input class="search-border" type="textbox" name="search-input" required/>
	            <input class="search" type="submit" name="search-submit" value="Search"/>
                <style>
                  .search{
                  background-color:rgba(10, 8, 129, 0.7);
                  color:white;
                   }
                </style>
         </form>
      </ul>
    </div>
</body>
</html>