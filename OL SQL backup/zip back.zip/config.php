<?php

$host = 'localhost';
$user = 'root';
$password = '';
$db = 'fourthecomm';

//set connection variables
$conn = mysqli_connect($host, $user, $password, $db);

?>